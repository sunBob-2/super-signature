These credentials exist to test the 'credentials directory' feature in isign.

The credentials are copied from ../credentials and just have the correct names.
