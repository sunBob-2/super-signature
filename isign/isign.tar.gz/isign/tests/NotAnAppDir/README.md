This is a directory which isign shouldn't accept as being an AppArchive
