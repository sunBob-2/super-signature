These credentials exist to test the 'multisign' feature in isign

The credentials are copied from ../credentials_std_names, and exist solely to have
a separate path to point to them.
