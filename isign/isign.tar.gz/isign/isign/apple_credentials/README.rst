These Apple credentials are public knowledge (see the docs) so they 
are okay to distribute. Don't put anything else here.
