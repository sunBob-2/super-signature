These scripts will re-provision (aka resign, code sign, etc) an app,
using Apple tools. The isign tools emulate what these do, on Linux.

provisions.sh is the original script that Mike Han (@mikehan) wrote.

provisions.py is a python port.
